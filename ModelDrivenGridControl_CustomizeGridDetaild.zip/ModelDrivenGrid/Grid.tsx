import { useConst, useForceUpdate } from '@fluentui/react-hooks';
import * as React from 'react';
import { IObjectWithKey, IRenderFunction, SelectionMode } from '@fluentui/react/lib/Utilities';
import { ConstrainMode, DetailsList, DetailsListLayoutMode, DetailsRow, IColumn, IDetailsHeaderProps, IDetailsListProps, IDetailsRowStyles } from '@fluentui/react/lib/DetailsList';
import { Sticky, StickyPositionType } from '@fluentui/react/lib/Sticky';
import { ContextualMenu, DirectionalHint, IContextualMenuProps } from '@fluentui/react/lib/ContextualMenu';
import { ScrollablePane, ScrollbarVisibility } from '@fluentui/react/lib/ScrollablePane';
import { Stack } from '@fluentui/react/lib/Stack';
import { Overlay } from '@fluentui/react/lib/Overlay';
import { IconButton } from '@fluentui/react/lib/Button';
import { Selection } from '@fluentui/react/lib/Selection';
import { Link } from '@fluentui/react/lib/Link';
import { Icon } from '@fluentui/react/lib/Icon';
import { Text } from '@fluentui/react/lib/Text';
import { Label } from '@fluentui/react/lib/Label';
import { mergeStyleSets } from '@fluentui/react/lib/Styling';
import { TextField } from '@fluentui/react/lib/TextField';
import { useState, useEffect } from 'react';
type DataSet = ComponentFramework.PropertyHelper.DataSetApi.EntityRecord & IObjectWithKey;
const classNames = mergeStyleSets({ cSSButton: { margin: '13px;' } });
const months = ['Jan-', 'Feb-', 'Mar-', 'Apr-', 'May-', 'Jun-', 'Jul-', 'Aug-', 'Sep-', 'Oct-', 'Nov-', 'Dec-'];
function stringFormat(template: string, ...args: string[]): string {
    for (const k in args) {
        template = template.replace('{' + k + '}', args[k]);
    }
    return template;
}
export interface GridProps {
    width?: number;
    height?: number;
    columns: ComponentFramework.PropertyHelper.DataSetApi.Column[];
    records: Record<string, ComponentFramework.PropertyHelper.DataSetApi.EntityRecord>;
    sortedRecordIds: string[];
    hasNextPage: boolean;
    hasPreviousPage: boolean;
    totalResultCount: number;
    currentPage: number;
    sorting: ComponentFramework.PropertyHelper.DataSetApi.SortStatus[];
    filtering: ComponentFramework.PropertyHelper.DataSetApi.FilterExpression;
    resources: ComponentFramework.Resources;
    itemsLoading: boolean;
    navigationEntityNameValue: string | null;
    navigationViewIdValue: string | null;
    stringStaticFields: string | null;
    setSelectedRecords: (ids: string[]) => void;
    onNavigate: (item?: ComponentFramework.PropertyHelper.DataSetApi.EntityRecord) => void;
    onSort: (name: string, desc: boolean) => void;
    onFilter: (name: string, filtered: boolean, valueFilter: string) => void;
    loadFirstPage: () => void;
    loadNextPage: () => void;
    loadPreviousPage: () => void;
    onFullScreen: () => void;
    isFullScreen: boolean;
    nextSixMonthsColumns: string[];
    refeshPage: () => void;
}
const onRenderDetailsHeader: IRenderFunction<IDetailsHeaderProps> = (props, defaultRender) => {
    if (props && defaultRender) {
        return (
            <Sticky stickyPosition={StickyPositionType.Header} isScrollSynced>
                {defaultRender({
                    ...props,
                })}
            </Sticky>
        );
    }
    return null;
};
export const Grid = React.memo((props: GridProps) => {
    const {
        records,
        sortedRecordIds,
        columns,
        width,
        height,
        hasNextPage,
        hasPreviousPage,
        sorting,
        filtering,
        currentPage,
        itemsLoading,
        setSelectedRecords,
        onNavigate,
        onSort,
        onFilter,
        resources,
        loadFirstPage,
        loadNextPage,
        loadPreviousPage,
        onFullScreen,
        isFullScreen,
        navigationEntityNameValue,
        navigationViewIdValue,
        stringStaticFields,
        totalResultCount,
        nextSixMonthsColumns,
        refeshPage,
    } = props;
    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth() + 1;
    // Generate columns dynamically for the next 6 months
    for (let i = currentMonth; i < currentMonth + 6; i++) {
        const monthIndex = i > 12 ? i % 12 : i;
        const month = months[monthIndex - 1];
        const year = i > 12 ? currentYear + 1 : currentYear;
        const columnKey = `${month}${String(year).substr(2)}`;
        nextSixMonthsColumns.push(columnKey)
    }
    const forceUpdate = useForceUpdate();
    const onSelectionChanged = React.useCallback(() => {
        const items = selection.getItems() as DataSet[];
        const selected = selection.getSelectedIndices().map((index: number) => {
            const item: DataSet | undefined = items[index];
            return item && items[index].getRecordId();
        });

        setSelectedRecords(selected);
        forceUpdate();
    }, [forceUpdate]);

    const selection: Selection = useConst(() => {
        return new Selection({
            selectionMode: SelectionMode.multiple,
            onSelectionChanged: onSelectionChanged,
        });
    });
    const [isComponentLoading, setIsLoading] = React.useState<boolean>(false);

    const [contextualMenuProps, setContextualMenuProps] = React.useState<IContextualMenuProps>();

    const onContextualMenuDismissed = React.useCallback(() => {
        setContextualMenuProps(undefined);
    }, [setContextualMenuProps]);

    const items: (DataSet | undefined)[] = React.useMemo(() => {
        setIsLoading(false);

        const sortedRecords: (DataSet | undefined)[] = sortedRecordIds.map((id) => {
            const record = records[id];
            return record;
        });

        return sortedRecords;
    }, [records, sortedRecordIds, hasNextPage, setIsLoading]);

    const getContextualMenuProps = React.useCallback(
        (column: IColumn, ev: React.MouseEvent<HTMLElement>): IContextualMenuProps => {
            const menuItems = [
                {
                    key: 'aToZ',
                    name: resources.getString('Label_SortAZ'),
                    iconProps: { iconName: 'SortUp' },
                    canCheck: true,
                    checked: column.isSorted && !column.isSortedDescending,
                    disable: (column.data as ComponentFramework.PropertyHelper.DataSetApi.Column).disableSorting,
                    onClick: () => {
                        onSort(column.key, false);
                        setContextualMenuProps(undefined);
                        if (items && items.length > 0) setIsLoading(true);
                    },
                },
                {
                    key: 'zToA',
                    name: resources.getString('Label_SortZA'),
                    iconProps: { iconName: 'SortDown' },
                    canCheck: true,
                    checked: column.isSorted && column.isSortedDescending,
                    disable: (column.data as ComponentFramework.PropertyHelper.DataSetApi.Column).disableSorting,
                    onClick: () => {
                        onSort(column.key, true);
                        setContextualMenuProps(undefined);
                        if (items && items.length > 0) setIsLoading(true);
                    },
                },
            ];
            return {
                items: menuItems,
                target: ev.currentTarget as HTMLElement,
                directionalHint: DirectionalHint.bottomLeftEdge,
                gapSpace: 10,
                isBeakVisible: true,
                onDismiss: onContextualMenuDismissed,
            };
        },
        [setIsLoading, onFilter, setContextualMenuProps, items],
    );

    const onColumnContextMenu = React.useCallback(
        (column?: IColumn, ev?: React.MouseEvent<HTMLElement>) => {
            if (column && ev) {
                setContextualMenuProps(getContextualMenuProps(column, ev));
            }
        },
        [getContextualMenuProps, setContextualMenuProps],
    );

    const onColumnClick = React.useCallback(
        (ev: React.MouseEvent<HTMLElement>, column: IColumn) => {
            if (column && ev) {
                setContextualMenuProps(getContextualMenuProps(column, ev));
            }
        },
        [getContextualMenuProps, setContextualMenuProps],
    );

    const onNextPage = React.useCallback(() => {
        setIsLoading(true);
        loadNextPage();
    }, [loadNextPage, setIsLoading]);

    const onPreviousPage = React.useCallback(() => {
        setIsLoading(true);
        loadPreviousPage();
    }, [loadPreviousPage, setIsLoading]);

    const onFirstPage = React.useCallback(() => {
        setIsLoading(true);
        loadFirstPage();
    }, [loadFirstPage, setIsLoading]);

    const gridColumns = React.useMemo(() => {
        return columns
            .filter((col) => {
                //stringStaticFields  JSON.parse(arr); '["New FL Number", "Replacing Asset FL Number", "Fleet Type", "Fleet No","Project Number","Project Name"]';
                //'["rtlme_name", "rtlme_replacingassetflnumber", "rtlme_fleettype1", "rtlme_fleetnumber","rtlme_projectnumber","rtlme_project"]'
                if (stringStaticFields !== null) {
                    const validJsonString = stringStaticFields.replace(/'/g, '"');
                    const isShowStaticFields = JSON.parse(validJsonString || '{}');
                    if (Object.keys(isShowStaticFields).length !== 0) {
                        if (!col.isHidden && col.order >= 0 && (nextSixMonthsColumns.includes(col.displayName) || isShowStaticFields.includes(col.name))) {
                            return true
                        }
                    }
                }
                return false;
            })
            .sort((a, b) => a.order - b.order)
            .map((col) => {
                const sortOn = sorting && sorting.find((s) => s.name === col.name);
                const filtered = filtering && filtering.conditions && filtering.conditions.find((f) => f.attributeName == col.name);
                return {
                    iconName: nextSixMonthsColumns.includes(col.displayName)
                        ? "AllCurrency"
                        : col.name === "rtlme_name" || col.name === "rtlme_replacingassetflnumber" || col.name === "rtlme_projectnumber"
                            ? "TextField"
                            : col.name === "rtlme_FleetType1" || col.name === "rtlme_FleetNumber" || col.name === "rtlme_Project"
                                ? "LookupEntities"
                                : "",
                    key: col.name,
                    name: " " + col.displayName,
                    fieldName: col.name,
                    isSorted: sortOn != null,
                    isSortedDescending: sortOn?.sortDirection === 1,
                    isResizable: true,
                    isRowHeader: true,
                    isFiltered: filtered != null,
                    data: col,
                    minWidth: col.visualSizeFactor > 100 ? col.visualSizeFactor : (col.name === "rtlme_replacingassetflnumber") ? 180 : 120,
                    className: "truncatableText-cf",
                    onColumnContextMenu: onColumnContextMenu,
                    onColumnClick: onColumnClick,
                } as IColumn;
            });
    }, [columns, sorting, onColumnContextMenu, onColumnClick]);

    const rootContainerStyle: React.CSSProperties = React.useMemo(() => {
        return {
            height: height === -1 ? '100%' : height,
            width: width,
        };
    }, [width, height]);

    const onRenderRow: IDetailsListProps['onRenderRow'] = (props) => {
        const customStyles: Partial<IDetailsRowStyles> = {};

        if (props && props.item) {
            const item = props.item as DataSet | undefined;
            return <DetailsRow {...props} styles={customStyles} />;
        }

        return null;
    };
    const _onFilter = (event: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>, newValue?: string) => {
        const validValue = newValue || '';
        const isInputEmpty = validValue.trim() === '';
        onFilter("rtlme_name", !isInputEmpty, validValue);
        setIsLoading(true);
    };
    const onRenderItemColumn = (
        item?: ComponentFramework.PropertyHelper.DataSetApi.EntityRecord,
        index?: number,
        column?: IColumn,
    ) => {
        if (column && column.fieldName && item) {
            const columnSlice = column.name.trim().slice(0, 4);
            const flocid = item?.getFormattedValue('rtlme_alme_flocid');
            const formattedValue = item?.getFormattedValue(column.fieldName);
            const url = `${Xrm.Utility.getGlobalContext().getCurrentAppUrl()}&pagetype=entityrecord&etn=rtlme_alme_floc&id=${flocid}`
            switch (column.key) {
                case 'rtlme_name':
                    return <Link className={'linkStyles-cf'} target="_self" href={url} >{formattedValue}</Link>;
                default:
                    if (months.includes(columnSlice)) {
                        const monthNumber = getValueByMonth(column.fieldName);
                        const [iconImgName, setIconImgName] = useState<string>("");
                        const [iconTooltip, setIconTooltip] = useState<string>("");
                        const [rtlme_cashflowId, setRtlme_cashflowId] = useState<string>("");
                        const [isLoading, setIsLoading] = useState<boolean>(true);
                        useEffect(() => {
                            if (monthNumber !== "0") {
                                AlreadyPaid(flocid, monthNumber)
                                    .then(resultArray => {
                                        const [imgName, tooltip, rtlme_cashflowId] = resultArray as string[];
                                        setIconImgName(imgName);
                                        setIconTooltip(tooltip);
                                        setRtlme_cashflowId(rtlme_cashflowId);
                                    })
                                    .catch(error => {
                                        console.error("Error:", error);
                                    })
                                    .finally(() => {
                                        setIsLoading(false);
                                    });
                            } else {
                                setIsLoading(false);
                            }
                        }, [flocid, monthNumber]);
                        return (
                            <>
                                {isLoading ? (
                                    <p></p>
                                ) : (
                                    <>
                                        {formattedValue && (
                                            <>
                                                <Label title={iconTooltip} style={{ color: iconImgName, float: 'left' }} onDoubleClick={(e) => onDoubleClick(e)} data-flocid={rtlme_cashflowId} className={'truncatableText-cf double-click'}>
                                                    {Math.sign(Number(formattedValue)) === -1 ? (
                                                        <>
                                                            {"($"}{(Math.abs(Number(formattedValue))).toFixed(2)}{")"}
                                                        </>
                                                    ) : (
                                                        <>
                                                            {"$"}{(Number(formattedValue)).toFixed(2)}
                                                        </>
                                                    )
                                                    }
                                                </Label>
                                            </>
                                        )}
                                        {!formattedValue && (
                                            <Label className={'truncatableText-cf'}>
                                                {formattedValue}
                                            </Label>
                                        )}
                                    </>
                                )}
                            </>
                        );
                    }
                    else {
                        return (
                            <>
                                {formattedValue && (
                                    <>
                                        <Label className={'truncatableText-cf'}>
                                            {formattedValue !== null && formattedValue !== "null" ? formattedValue : ""}
                                        </Label>
                                    </>
                                )}
                                {!formattedValue && (
                                    <></>
                                )}
                            </>
                        )
                    }
            }
        }
        return <></>;
    };
    function onDoubleClick(e: any) {
        const removeId = e.target.getAttribute("data-flocid");
        console.log("*4");
        navigatEntityRecord(removeId, "rtlme_cashflow");
    }
    function AlreadyPaid(flocId: string, optionSetMonthValue: string) {
        const numverFinal = parseInt(optionSetMonthValue);
        const fetchXml = "?fetchXml=<fetch version='1.0' mapping='logical' no-lock='false' distinct='true'><entity name='rtlme_cashflow'><attribute name='rtlme_paid'/><attribute name='rtlme_name'/><attribute name='rtlme_cashflowid'/><filter type='and'><condition attribute='rtlme_floc' operator='eq' value='{" + flocId + "}' uitype='rtlme_alme_floc'/><condition attribute='rtlme_month' operator='eq' value='" + numverFinal + "'/></filter></entity></fetch>";
        return new Promise(function (resolve, reject) {
            Xrm.WebApi.retrieveMultipleRecords("rtlme_cashflow", fetchXml).then(function (result) {
                const resultarray = CalculateIconCashFlow(result);
                console.log(resultarray);
                resolve(resultarray);
            }).catch(function (err) {
                reject(err);
                console.log(err);
            });
        });
    }
    function getValueByMonth(monthName: string) {
        const month = monthName.slice(6, 9); // "aug"
        const year = monthName.slice(-2);    // "23"
        let numericMonth;
        switch (month) {
            case "jan":
                numericMonth = "01";
                break;
            case "feb":
                numericMonth = "02";
                break;
            case "mar":
                numericMonth = "03";
                break;
            case "apr":
                numericMonth = "04";
                break;
            case "may":
                numericMonth = "05";
                break;
            case "jun":
                numericMonth = "06";
                break;
            case "jul":
                numericMonth = "07";
                break;
            case "aug":
                numericMonth = "08";
                break;
            case "sep":
                numericMonth = "09";
                break;
            case "oct":
                numericMonth = "10";
                break;
            case "nov":
                numericMonth = "11";
                break;
            case "dec":
                numericMonth = "12";
                break;
            default:
                numericMonth = "0";
        }
        if (numericMonth === "0") {
            return "0";
        }
        const numericYear = parseInt(year, 10);
        const resultNumber = `1${numericMonth}20${numericYear}`;
        return resultNumber;
    }
    function CalculateIconCashFlow(result: Xrm.RetrieveMultipleResult) {
        let imgName = "";
        let tooltip = "";
        let rtlme_cashflowId = "";
        if (result != null && result != undefined && result.entities != null && result.entities.length > 0) {
            //rtlme_paid
            rtlme_cashflowId = result.entities[0].rtlme_cashflowid;
            if (result.entities[0].rtlme_paid == 1) {
                imgName = "#48b161";
                tooltip = "Already Paid";
            }
            else {
                imgName = "red";
                tooltip = "Not Paid"
            }
            //
        }
        return [imgName, tooltip, rtlme_cashflowId];
    }
    function navigatEntityRecord(idRecord: string, etn: string) {
        const navigationEntityName: string = etn as string;
        try {
            const navigationOptions: Xrm.Navigation.NavigationOptions = {
                target: 2,
                width: { value: 50, unit: "%" },
                position: 1
            };
            const entityrecord: Xrm.Navigation.PageInputEntityRecord = {
                pageType: "entityrecord",
                entityName: navigationEntityName,
                entityId: idRecord
            };
            openEntityRecord(entityrecord, navigationOptions);
        }
        catch (error) {
            console.log(`buttonClick error`, error);
        }
        finally {
            console.log(`buttonClick finally`);
        }
    }
    async function openEntityRecord(pageInput: Xrm.Navigation.PageInputEntityRecord, navigationOptions: Xrm.Navigation.NavigationOptions | undefined) {
        Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(() => {
            refeshPage();
            forceUpdate();
        }, (e) => console.log(e));
    }
    return (
        <Stack verticalFill grow style={rootContainerStyle}>
            <Stack.Item>
                <Stack horizontal style={{ float: 'right' }}>
                    <Link className={'showall-cf'} target="_self" href={`${Xrm.Utility.getGlobalContext().getCurrentAppUrl()}&pagetype=entitylist&etn=rtlme_alme_floc&viewid=${navigationViewIdValue}`} > <Icon iconName='Money'></Icon>  Show all Cash Flows</Link>
                    <TextField className={classNames.cSSButton} placeholder="Filter by keyword" onChange={_onFilter} style={{ float: 'right' }} />
                </Stack>
            </Stack.Item>
            <Stack.Item grow style={{ position: 'relative', backgroundColor: 'white', zIndex: 0 }}>
                <ScrollablePane scrollbarVisibility={ScrollbarVisibility.auto}>
                    <DetailsList
                        columns={gridColumns}
                        onRenderItemColumn={onRenderItemColumn}
                        onRenderDetailsHeader={onRenderDetailsHeader}
                        items={items}
                        setKey={`set${currentPage}`} // Ensures that the selection is reset when paging
                        initialFocusedIndex={0}
                        checkButtonAriaLabel="select row"
                        layoutMode={DetailsListLayoutMode.fixedColumns}
                        constrainMode={ConstrainMode.unconstrained}
                        selection={selection}
                        onItemInvoked={onNavigate}
                        onRenderRow={onRenderRow}
                    ></DetailsList>
                    {itemsLoading && isComponentLoading && items && items.length === 0 && (
                        <Stack grow horizontalAlign="center" className={'noRecords'}>
                            <Icon iconName="PageList"></Icon>
                            <Text variant="large">{resources.getString('Label_NoRecords')}</Text>
                        </Stack>
                    )}
                    {contextualMenuProps && <ContextualMenu {...contextualMenuProps} />}
                </ScrollablePane>
                {(itemsLoading || isComponentLoading) && <Overlay />}
            </Stack.Item>
            <Stack.Item>
                <Stack horizontal style={{ width: '100%', paddingLeft: 8, paddingRight: 8 }}>
                    <Stack.Item align="center">
                        {stringFormat(
                            resources.getString('Label_Grid_Footer_RecordCount'),
                            totalResultCount === -1 ? '5000+' : totalResultCount.toString(),
                            selection.getSelectedCount().toString(),
                        )}
                    </Stack.Item>
                    <Stack.Item grow align="center" style={{ textAlign: 'center' }}>
                        {!isFullScreen && (
                            <Link></Link>
                        )}
                    </Stack.Item>
                    <IconButton
                        alt="First Page"
                        iconProps={{ iconName: 'Rewind' }}
                        disabled={!hasPreviousPage || isComponentLoading || itemsLoading}
                        onClick={onFirstPage}
                    />
                    <IconButton
                        alt="Previous Page"
                        iconProps={{ iconName: 'Previous' }}
                        disabled={!hasPreviousPage || isComponentLoading || itemsLoading}
                        onClick={onPreviousPage}
                    />
                    <Stack.Item align="center">
                        {stringFormat(
                            resources.getString('Label_Grid_Footer'),
                            currentPage.toString(),
                            selection.getSelectedCount().toString(),
                        )}
                    </Stack.Item>
                    <IconButton
                        alt="Next Page"
                        iconProps={{ iconName: 'Next' }}
                        disabled={!hasNextPage || isComponentLoading || itemsLoading}
                        onClick={onNextPage}
                    />
                </Stack>
            </Stack.Item>
        </Stack>
    );
});
Grid.displayName = 'Grid';

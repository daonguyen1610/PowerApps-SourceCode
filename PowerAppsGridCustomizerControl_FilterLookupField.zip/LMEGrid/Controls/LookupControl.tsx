import * as React from 'react';
import { Dropdown, IDropdownOption } from '@fluentui/react/lib/Dropdown';
interface ILoopkupProps {
    etn: string;
    lookupId: string;
    fleetnumberId: string;
    webAPI: ComponentFramework.WebApi;
    lookupCache: any;
    onChange: (selectedItems: ComponentFramework.EntityReference[] | undefined) => void;
}
export const LookupControl = React.memo(function PeopleRaw({ etn, lookupId, fleetnumberId, webAPI, lookupCache, onChange }: ILoopkupProps) {
    const [showError, setError] = React.useState(false);
    const [options, setLookup] = React.useState<Array<any> | null>(lookupCache[fleetnumberId ?? ""] ?? null);
    const mounted = React.useRef(false);
    if (!fleetnumberId || fleetnumberId === "") {
        setError(true);
    }
    const _onSelectedChanged = (event: any, selectedItems?: IDropdownOption) => {
        onChange([
            {
                id: { guid: selectedItems?.key as string },
                name: selectedItems?.text || "",
                etn: etn,
            }
        ]
        )
    }
    React.useEffect(() => {
        mounted.current = true;
        return () => {
            mounted.current = false;
        };
    }, []);
    React.useEffect(() => {
        if (fleetnumberId !== null && fleetnumberId !== "") {
            const attributeName = (etn === "rtlme_alme_supplier") ?
                `<attribute name="rtlme_name"/><attribute name="rtlme_alme_supplierid"/><attribute name="rtlme_fleetnumber"/>` :
                (etn === "rtlme_fleettype") ? `<attribute name="rtlme_name"/><attribute name="rtlme_fleettypeid"/><attribute name="rtlme_fleetname"/>` : '';

            webAPI.retrieveMultipleRecords(etn, ["?fetchXml=",
                `<fetch distinct="false" mapping="logical" returntotalrecordcount="true" no-lock="true">`,
                `<entity name="${etn}">`,
                attributeName,
                `<filter type="and">`,
                `<condition attribute="rtlme_fleetnumber" operator="eq" uitype="${etn}" value="{${fleetnumberId}}"/>`,
                `</filter>`,
                `</entity>`,
                `</fetch>`].join('')).then((result) => {
                    if (mounted.current) {
                        const optionsDropdown = (result.entities as IDropdownOption[]).map((option: any) => {
                            return { key: (etn === "rtlme_alme_supplier") ? option?.rtlme_alme_supplierid : option?.rtlme_fleettypeid, text: option?.rtlme_name }
                        });
                        setLookup(optionsDropdown);
                    }
                });
        }
    }, [fleetnumberId]);
    return <Dropdown
        options={options || []}
        defaultSelectedKey={lookupId}
        onChange={_onSelectedChanged}
        className="ComboBox"
    />
});

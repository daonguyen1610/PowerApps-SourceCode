import { Label } from '@fluentui/react';
import * as React from 'react';
import { CellRendererOverrides, CellRendererProps } from '../types';
import { useState } from 'react';
const MONTH_MAPPING: { [key: string]: string } = {
    "jan": "01", "feb": "02", "mar": "03", "apr": "04", "may": "05", "jun": "06",
    "jul": "07", "aug": "08", "sep": "09", "oct": "10", "nov": "11", "dec": "12"
};
export interface ICurrencyProps {
    prop: CellRendererProps;
    formattedValue: string | undefined;
    monthNumber: string | undefined;
    flocid: string | undefined;
}
export const generateCellRendererOverrides = () => {
    const cellRendererOverrides: CellRendererOverrides = {
        //Format currency RED is Not Paid/ Green is Paid
        //Currency alight left
        ["Currency"]: (props, col) => {
            props.cellContainerElement?.classList.add('currency-custom');
            const columnName = col.colDefs[col.columnIndex].name;
            const monthNumber = getValueByMonth(columnName);
            const flocid = col.rowData?.__rec_id;
            if (props.formattedValue !== null && props.formattedValue !== "" && monthNumber !== "0") {
                return <Currency prop={props} formattedValue={props.formattedValue} flocid={flocid} monthNumber={monthNumber} />
            }
            else {
                return null;
            }

        },
    }
    return cellRendererOverrides;
}
export const Currency = React.memo(function PeopleRaw({ prop, formattedValue, monthNumber, flocid }: ICurrencyProps) {
    const [colorString, setColor] = useState<string>("");
    const [tooltipString, seTooltip] = useState<string>("");
    React.useEffect(() => {
        if (flocid && monthNumber) {
            AlreadyPaid(flocid, monthNumber)
                .then(resultArray => {
                    const [color, tooltip] = resultArray as string[];
                    setColor(color);
                    seTooltip(tooltip);
                    if (color === "red") {
                        prop.cellContainerElement?.classList.add('red');
                    }
                    else if (color === "green") {
                        prop.cellContainerElement?.classList.add('green');
                    }
                    return null;
                })
                .catch(error => {
                    console.error("Error:", error);
                });
        }
    }, [flocid, monthNumber]);
    return (
        <>
            <Label title={tooltipString} className={'currency-custom'} style={{ color: colorString }}>{formattedValue}</Label>
        </>
    )
});
function CalculateIconCashFlow(result: Xrm.RetrieveMultipleResult) {
    let color = "";
    let tooltip = "";
    if (result != null && result != undefined && result.entities != null && result.entities.length > 0) {
        //rtlme_paid
        if (result.entities[0].rtlme_paid == 1) {
            color = "green";
            tooltip = "Already Paid";
        }
        else if (result.entities[0].rtlme_paid == 0) {
            color = "red";
            tooltip = "Not Paid";
        }
        else {
            color = "black";
            tooltip = ""
        }
        //
    }
    return [color, tooltip];
}
function getValueByMonth(monthName: string) {
    const month = monthName.slice(6, 9);
    const year = monthName.slice(-2);
    const numericMonth = MONTH_MAPPING[month] || "0";

    if (numericMonth === "0") {
        return "0";
    }

    const numericYear = parseInt(year, 10);
    return `1${numericMonth}20${numericYear}`;
}
function AlreadyPaid(flocId: string, optionSetMonthValue: string) {
    const numverFinal = parseInt(optionSetMonthValue);
    const fetchXml = "?fetchXml=<fetch version='1.0' mapping='logical' no-lock='false' distinct='true'><entity name='rtlme_cashflow'><attribute name='rtlme_paid'/><filter type='and'><condition attribute='rtlme_floc' operator='eq' value='{" + flocId + "}' uitype='rtlme_alme_floc'/><condition attribute='rtlme_month' operator='eq' value='" + numverFinal + "'/></filter></entity></fetch>";
    return new Promise(function (resolve, reject) {
        Xrm.WebApi.retrieveMultipleRecords("rtlme_cashflow", fetchXml).then(function (result) {
            const resultarray = CalculateIconCashFlow(result);
            resolve(resultarray);
        }).catch(function (err) {
            reject(err);
        });
    });
}




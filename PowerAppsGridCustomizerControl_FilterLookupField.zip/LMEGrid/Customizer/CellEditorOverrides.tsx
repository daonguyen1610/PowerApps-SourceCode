import * as React from 'react';
import { CellEditorOverrides, FleetNumber, FleetType, Supplier } from '../types';
import { LookupControl } from '../Controls/LookupControl';
import { Dropdown } from '@fluentui/react/lib/Dropdown';
export const generateCellEditorOverrides = (webAPI: ComponentFramework.WebApi, lookupCache: any) => {
  const cellEditorOverrides: CellEditorOverrides = {
    ["Currency"]: (props, col) => {
      col.eGridCell?.classList?.add("editing-currency");
      return null;
    },
    //Filter options in dropdown lookup by FleetNo
    ["Lookup"]: (props, col) => {
      const columnName = col.colDefs[col.columnIndex].name;
      if (columnName === "rtlme_supplier") {
        col.eGridCell?.classList?.add("lookupEdit");
        const fleetnumberId = col.rowData?.[FleetNumber] !== null ? col.rowData?.[FleetNumber]?.id?.guid as string : "";
        const supplierId = col.rowData?.[Supplier] !== null ? col.rowData?.[Supplier]?.id?.guid as string : "";
        const onChange = (selectedItems?: ComponentFramework.EntityReference[] | undefined) => {
          col.onCellValueChanged(selectedItems ? selectedItems[0] : null);
          col.stopEditing(true);
        }
        if (fleetnumberId !== "") {
          return <LookupControl etn={"rtlme_alme_supplier"} lookupId={supplierId} fleetnumberId={fleetnumberId} webAPI={webAPI} lookupCache={lookupCache} onChange={onChange} />
        }
        else {
          col.onCellValueChanged(null);
          return <Dropdown
            options={[]}
            className="ComboBox_Error"
            errorMessage={'Please select a Fleet No!'}
          />
        }
      }
      else if (columnName === "rtlme_fleettype1") {
        col.eGridCell?.classList?.add("lookupEdit");
        const fleetnumberId = col.rowData?.[FleetNumber] !== null ? col.rowData?.[FleetNumber]?.id?.guid as string : "";
        const fleettypeId = col.rowData?.[FleetType] !== null ? col.rowData?.[FleetType]?.id?.guid as string : "";
        const onChange = (selectedItems?: ComponentFramework.EntityReference[] | undefined) => {
          col.onCellValueChanged(selectedItems ? selectedItems[0] : null);
          col.stopEditing(true);
        }
        if (fleetnumberId !== "") {
          return <LookupControl etn={"rtlme_fleettype"} lookupId={fleettypeId} fleetnumberId={fleetnumberId} webAPI={webAPI} lookupCache={lookupCache} onChange={onChange} />
        }
        else {
          col.onCellValueChanged(null);
          return <Dropdown
            options={[]}
            className="ComboBox_Error"
            errorMessage={'Please select a Fleet No!'}
          />
        }
      }
      else if (columnName === "rtlme_fleetnumber") {
        col.eGridCell?.classList?.add("lookupEdit");
        props.onChange = (e?: unknown) => {
          if (col.rowData) {
            col.rowData[FleetType] = null;
            col.rowData[Supplier] = null;
          }
          col.onCellValueChanged(e || null);
          col.stopEditing(true);
        }
        return null;
      }
      else {
        return null;
      }
    }
  }
  return cellEditorOverrides;
}
